import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menugrazietea',
  templateUrl: './menugrazietea.component.html',
  styleUrls: ['./menugrazietea.component.css']
})
export class MenugrazieteaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
