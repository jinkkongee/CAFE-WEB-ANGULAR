import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menugraziesmoothiemi',
  templateUrl: './menugraziesmoothiemi.component.html',
  styleUrls: ['./menugraziesmoothiemi.component.css']
})
export class MenugraziesmoothiemiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
