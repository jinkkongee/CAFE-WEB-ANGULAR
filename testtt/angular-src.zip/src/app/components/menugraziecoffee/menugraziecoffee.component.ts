import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menugraziecoffee',
  templateUrl: './menugraziecoffee.component.html',
  styleUrls: ['./menugraziecoffee.component.css']
})
export class MenugraziecoffeeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
