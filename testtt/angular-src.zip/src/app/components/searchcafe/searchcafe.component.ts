import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-searchcafe',
  templateUrl: './searchcafe.component.html',
  styleUrls: ['./searchcafe.component.css']
})
export class SearchcafeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
