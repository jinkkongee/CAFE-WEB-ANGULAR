import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menugrazielatte',
  templateUrl: './menugrazielatte.component.html',
  styleUrls: ['./menugrazielatte.component.css']
})
export class MenugrazielatteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
