import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menugraziecoffeemi',
  templateUrl: './menugraziecoffeemi.component.html',
  styleUrls: ['./menugraziecoffeemi.component.css']
})
export class MenugraziecoffeemiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
