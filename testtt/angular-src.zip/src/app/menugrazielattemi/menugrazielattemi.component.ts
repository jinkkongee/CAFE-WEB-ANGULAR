import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menugrazielattemi',
  templateUrl: './menugrazielattemi.component.html',
  styleUrls: ['./menugrazielattemi.component.css']
})
export class MenugrazielattemiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
