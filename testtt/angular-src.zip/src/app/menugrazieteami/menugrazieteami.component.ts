import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menugrazieteami',
  templateUrl: './menugrazieteami.component.html',
  styleUrls: ['./menugrazieteami.component.css']
})
export class MenugrazieteamiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
