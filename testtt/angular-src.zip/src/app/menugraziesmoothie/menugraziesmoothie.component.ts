import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menugraziesmoothie',
  templateUrl: './menugraziesmoothie.component.html',
  styleUrls: ['./menugraziesmoothie.component.css']
})
export class MenugraziesmoothieComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
